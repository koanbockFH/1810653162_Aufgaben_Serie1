package ac.at.fhkufstein;

public class NewClass {

    public static void main(String[] args){
        System.out.println("FH Kufstein Tirol");
    }
}
